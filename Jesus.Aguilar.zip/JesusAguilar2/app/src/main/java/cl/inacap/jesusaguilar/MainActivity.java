package cl.inacap.jesusaguilar;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.util.ArrayList;
import cl.ejemplos.listadecomprasinacap2022.modelo.ListaMascotas;
import cl.ejemplos.listadecomprasinacap2022.modelo.Mascota;


public class MainActivity extends AppCompatActivity {

    private Mascota Mascota= cl.inacap.jesusaguilar.Mascota.getEspecie();
    private ArrayList<ListaMascotas> ListaMascotas=Mascota.getMascota();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button ver_lista=(Button) findViewById(R.id.ver_lista);
        ver_lista.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                if(Mascota.size()>0) {
                    Intent intent = new Intent(MainActivity.this, ListaMascotas.class);
                    startActivity(intent);
                }
                else
                {
                    Toast.makeText(MainActivity.this, "La lista está vacía",Toast.LENGTH_SHORT).show();
                }
            }
        });

        Button botonNuevo=(Button) findViewById(R.id.botonNuevo);
        botonNuevo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(MainActivity.this, NuevoProductoActivity.class);
                startActivity(intent);
            }
        });
    }

}