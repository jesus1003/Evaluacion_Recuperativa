package cl.inacap.jesusaguilar;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class ListaMascotas extends AppCompatActivity {

    EditText etEnviar;
    Button btnEnviar;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ListaMascotas);

        etEnviar = findViewById(R.id.editTextNumber);
        btnEnviar = findViewById(R.id.button3);

        String[] datos = new String[]{"nombre", "especie", "nombrePropietario", "telefonoPropietario", "edad"}

        etEnviar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Bundle enviaDatos =new Bundle();
                enviaDatos.putString("keyDatos", datos);

                Intent Intent = new Intent(ListaMascotas.this, DetallesActivity.class);
                Intent.putExtra(enviaDatos);
                startActivity(intent);
            }
        });
    }

    private static ListaMascotas Mascota =new ListaMascotas();
    private ArrayList<Mascota> ListaMascotas;

    private ListaMascotas() {
        ListaMascotas=new ArrayList<>();

    }
    public static ListaMascotas getMascota()
    {
        return Mascota;
    }

    public void agregarProducto(Mascota Mascota)
    {
        ListaMascotas.add(Mascota);
    }

    public Mascota getMascota(int id)
    {
        return ListaMascotas.get(id);
    }
    public ArrayList<Mascota> getListaMascotaActivity()
    {
        return ListaMascotas;
    }

    public void eliminar()
    {
        for(int i=0; i<ListaMascotas.size();i++)
        {
            if(ListaMascotas.get(i).isEstado()== cl.inacap.jesusaguilar.Mascota.COMPRADO)
            {
                ListaMascotas.remove(i);
                i--;
            }
        }
    }
}
