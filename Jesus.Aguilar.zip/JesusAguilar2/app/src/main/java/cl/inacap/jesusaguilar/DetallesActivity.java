package cl.inacap.jesusaguilar;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;

public class DetallesActivity extends AppCompatActivity {

    TextView tvDatos

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalles);

        tvDatos = findViewById(R.id.textViewDatos);

        Bundle recibeDatos = getIntent().getExtras();
        String info = recibeDatos.getString("keyDatos");

        tvDatos.setText("Nombre: " + info[0] + "\nEspecie: " + info[1] + "\nnombrePropietario: " + info[2] + "\ntelefonoPropietario: " + info[3] + "\nEdad" + info[4]);


    }

    public void eliminarMascota() {
        for (int i = 0; i < ListaMascotas.size(); i++) {
            if (ListaMascotas.get(i).isEstado() == Mascota.creada) {
                ListaMascotas.remove(i);
                i--;
            }
        }
    }
}

