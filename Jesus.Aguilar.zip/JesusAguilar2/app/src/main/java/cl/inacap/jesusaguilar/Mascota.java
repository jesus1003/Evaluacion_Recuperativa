package cl.inacap.jesusaguilar;

public class Mascota {
    private String Nombre;
    private String Especie;
    private String nombrePropietario;
    private String telefonoPropietario;
    private int Edad;

    public Mascota(String nombre) {
        Nombre = nombre;
    }

    public Mascota(String Especie) {
        Especie = Especie;
    }

    public Mascota(String nombrePropietario) {
        nombrePropietario = nombrePropietario;
    }

    public Mascota(int edad) {
        Edad = edad;
    }

    @Override
    public String toString() {
        return "Mascota{" +
                "Nombre='" + Nombre + '\'' +
                ", Especie='" + Especie + '\'' +
                ", nombrePropietario='" + nombrePropietario + '\'' +
                ", telefonoPropietario='" + telefonoPropietario + '\'' +
                ", Edad=" + Edad +
                '}';
    }

    public String getNombre() {
        return Nombre;
    }



    public void setNombre(String nombre) {
        Nombre = nombre;
    }

    public String getEspecie() {
        return Especie;
    }

    public void setEspecie(String especie) {
        Especie = especie;
    }

}
