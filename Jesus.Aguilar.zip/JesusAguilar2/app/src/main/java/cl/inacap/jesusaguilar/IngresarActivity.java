package cl.inacap.jesusaguilar;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;


import android.os.Bundle;

public class ListaMascotas extends AppCompatActivity {

    private Button mBtnToast;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ingresar);

        mBtnToast = (Button) findViewById(R.id.buttonToast);

        mBtnToast.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Toast.makeText(MainActivity.this, "se presento un error", Toast.LENGTH_SHORT).show();
            }
        });
    }


    public class IngresarActivity extends AppCompatActivity {

        private ListaMascotas ListaMascotas= cl.inacap.jesusaguilar.ListaMascotas.getInstancia();

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_ingresar);
            Button botonIngresarActivity=(Button) findViewById(R.id.botonIngresarActivity);
            botonIngresarActivity.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    ingresarActivity(view);
                }
            });
        }

        public void ingresarActivity(View view)
        {
            String nombre=((TextView) findViewById(R.id.ingresarNombre)).getText().toString();
            String Especie=((TextView) findViewById(R.id.ingresarEspecie)).getText().toString();
            String telefonoPropietario=((Spinner) findViewById(R.id.ingresarTelefono)).getSelectedItem().toString();
            String nombrePropietario=((TextView) findViewById(R.id.nombrePropietario)).getText().toString();

            }
        }
}